package com.exceltomysql.demo;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ExcelDataRepository extends JpaRepository<ExcelData, Long> {
}
