package com.crick;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrcketInformationApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrcketInformationApplication.class, args);
	}

}
