package com.crick;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrcketInformationApplicationTests {

	@Test
	void contextLoads() {
	}

}
