package com.exceltomysql.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExcelToDbApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExcelToDbApplication.class, args);
	}

}
